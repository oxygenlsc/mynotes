function test(a, b, ...args) {
    
}

test(1, 32, 46, 7, 34); 
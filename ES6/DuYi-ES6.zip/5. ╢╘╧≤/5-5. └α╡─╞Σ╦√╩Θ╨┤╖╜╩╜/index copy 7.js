const A = class { //匿名类，类表达式
    a = 1;
    b = 2;
}

const a = new A();
console.log(a)
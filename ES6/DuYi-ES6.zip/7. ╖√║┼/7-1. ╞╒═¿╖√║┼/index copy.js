//创建一个符号

const syb1 = Symbol();
const syb2 = Symbol("abc");

console.log(syb1, syb2);